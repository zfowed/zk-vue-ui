((typeof self !== 'undefined' ? self : this)["webpackJsonpzkm_vue_ui"] = (typeof self !== 'undefined' ? self : this)["webpackJsonpzkm_vue_ui"] || []).push([[32],{

/***/ "fcc3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0a9c");

/* harmony default export */ __webpack_exports__["default"] = (_table__WEBPACK_IMPORTED_MODULE_0__["TableBody"]);

/***/ })

}]);
//# sourceMappingURL=zkm-vue-ui.umd.zk-table-body.js.map