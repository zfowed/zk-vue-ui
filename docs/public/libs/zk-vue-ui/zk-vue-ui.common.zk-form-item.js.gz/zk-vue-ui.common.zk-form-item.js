((typeof self !== 'undefined' ? self : this)["webpackJsonpzk_vue_ui"] = (typeof self !== 'undefined' ? self : this)["webpackJsonpzk_vue_ui"] || []).push([[15],{

/***/ "5db4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2a49");

/* harmony default export */ __webpack_exports__["default"] = (_form__WEBPACK_IMPORTED_MODULE_0__["FormItem"]);

/***/ })

}]);
//# sourceMappingURL=zk-vue-ui.common.zk-form-item.js.map